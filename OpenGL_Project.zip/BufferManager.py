import array
from Buffer import *

vao=0
pdata=[]
pbuff=None
ndata=[]
nbuff=None
idata=[]
ibuff=None
tanbuff=None
tandata=[]
basedata=[]
basebuff=None
bumpdata=[]
bumpbuff=None

def addData( newpdata ):
    global vao, pdata
    if vao != 0:
        raise RuntimeError("Cannot add data after pushToGPU() has been called")
    assert type(newpdata) == list
    oldSize = len(pdata)//3        #get number of points in list
    pdata += newpdata
    return oldSize
 
def addIndexedData(*, positiondata, basetexturedata, bumptexturedata, normaldata, tangentdata, indexdata):
    global vao, pdata, basedata, bumpdata, idata, ndata, tandata
    if vao != 0:
        raise RuntimeError("Cannot add data after pushToGPU() has been called")
    assert type(positiondata) == list
    assert type(basetexturedata) == list    
    assert type(bumptexturedata) == list
    assert type(normaldata) == list       
    assert type(indexdata) == list
    assert type(tangentdata) == list
    assert len(positiondata)//3 == len(basetexturedata)//2    
    assert len(positiondata)//3 == len(normaldata)//3   
    startingVertexNumber = len(pdata)//3
    indexStart = len(idata)
    pdata += positiondata          
    ndata += normaldata
    idata += indexdata
    tandata += tangentdata
    basedata += basetexturedata
    bumpdata += bumptexturedata
    return startingVertexNumber,indexStart*4
    
def pushToGPU():
    global vao
    global pbuff,basebuff,bumpbuff,ibuff,tanbuff
    global pdata,basedata,bumpdata,idata,tandata
    pbuff = Buffer( array.array( "f", pdata ) )
    basebuff = Buffer( array.array( "f", basedata ) )  
    bumpbuff = Buffer( array.array( "f", bumpdata ) )
    nbuff = Buffer( array.array( "f", ndata ) )    
    ibuff = Buffer( array.array( "I", idata ) )
    tanbuff = Buffer( array.array( "f", tandata ) )
    tmp = array.array("I",[0])
    glGenVertexArrays(1,tmp)
    vao = tmp[0]
    glBindVertexArray(vao)
    ibuff.bind(GL_ELEMENT_ARRAY_BUFFER)
    pbuff.bind(GL_ARRAY_BUFFER)
    glEnableVertexAttribArray(0)
    glVertexAttribPointer( 0, 3, GL_FLOAT, False, 3*4, 0 )
    basebuff.bind(GL_ARRAY_BUFFER)         
    glEnableVertexAttribArray(1)            
    glVertexAttribPointer( 1, 2, GL_FLOAT, False, 2*4, 0 )  
    nbuff.bind(GL_ARRAY_BUFFER)        
    glEnableVertexAttribArray(2)            
    glVertexAttribPointer( 2, 3, GL_FLOAT, False, 3*4, 0 )  
    tanbuff.bind(GL_ARRAY_BUFFER)
    glEnableVertexAttribArray(3)
    glVertexAttribPointer( 3, 4, GL_FLOAT, False, 4*4, 0 )
    bumpbuff.bind(GL_ARRAY_BUFFER)
    glEnableVertexAttribArray(4)            
    glVertexAttribPointer( 4, 2, GL_FLOAT, False, 2*4, 0 )  

def bind():
    if not vao:
        raise RuntimeError("Data hasn't been pushed to GPU")
    glBindVertexArray(vao)
